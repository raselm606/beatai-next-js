import Image from 'next/image';
import Marquee from "react-fast-marquee";
import glance_one from '../../public/beatai_assets/images/glance/at-a-glance-icon-1.svg';
import glance_two from '../../public/beatai_assets/images/glance/at-a-glance-icon-2.svg';
import glance_big_img from '../../public/beatai_assets/images/glance/at-a-glance2.png';
import slide4 from '../../public/beatai_assets/images/glance/slide10.png';
import slide6 from '../../public/beatai_assets/images/glance/slide11.png';
import slide12 from '../../public/beatai_assets/images/glance/slide12.png';
import slide13 from '../../public/beatai_assets/images/glance/slide13.png';
import slide14 from '../../public/beatai_assets/images/glance/slide14.png';
import slide15 from '../../public/beatai_assets/images/glance/slide15.png';
import slide5 from '../../public/beatai_assets/images/glance/slide5.svg';
import slide1 from '../../public/beatai_assets/images/glance/slide7.png';
import slide2 from '../../public/beatai_assets/images/glance/slide8.png';
import slide3 from '../../public/beatai_assets/images/glance/slide9.png';
const AtaGlance = () => {
  return (
    <>
      <div className="ataglance_section section_padding" id="at-a-glance">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-6 mb-3">
              <div className="glance_left_img">
                <Image  data-aos="fade-up" src={glance_big_img} alt="glance_big_img image" />
              </div>
            </div>
            <div className="col-lg-6 mb-3">
              <div className="section_title">
                <span data-aos="fade-up">At a glance</span>
                <h2 data-aos="fade-up">Instant Visual Magic at a Glance!</h2>
                <p data-aos="fade-up"> AI isn’t here to replace human creativity, it’s here to amplify it, empowering you to achieve unprecedented heights.  </p>
                <p data-aos="fade-up">Whether you’re crafting fanart of your favorite anime or exploring new artistic frontiers, AI can be your creative partner, empowering you to bring your imagination to life like never before.</p>
              </div>
              <div className="icon_items_glance">
                <ul className="icon_ul">
                  <li data-aos="fade-up">
                    <Image src={glance_one} alt="glance_one" /> 
                  Where Human Creativity Meets AI Possibility
                  </li>
                  <li data-aos="fade-up">
                    <Image src={glance_two} alt="glance_two image" /> 
                  Unleash your imagination and create more with BeatAI
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid mt-9">
          <div className="row">
            <Marquee speed={60} gradient={false}> 
            <div className="col mb-3">
              <div className="slide_item_img">
                <Image src={slide1} alt="image" />
              </div>
            </div>
            <div className="col mb-3 mt-7">
              <div className="slide_item_img">
                <Image src={slide6} alt="image" />
              </div>
            </div>
            <div className="col mb-3 ">
              <div className="slide_item_img">
                <Image src={slide2} alt="image" />
              </div>
            </div>
            <div className="col mb-3 mt-7">
              <div className="slide_item_img">
                <Image src={slide3} alt="image" />
              </div>
            </div>
            <div className="col mb-3 ">
              <div className="slide_item_img">
                <Image src={slide4} alt="image" />
              </div>
            </div>
            <div className="col mb-3 mt-7">
              <div className="slide_item_img">
                <Image src={slide5} alt="image" />
              </div>
            </div>
            <div className="col mb-3 ">
              <div className="slide_item_img">
                <Image src={slide12} alt="image" />
              </div>
            </div>
            <div className="col mb-3 mt-7">
              <div className="slide_item_img">
                <Image src={slide13} alt="image" />
              </div>
            </div>
            <div className="col mb-3 ">
              <div className="slide_item_img">
                <Image src={slide14} alt="image" />
              </div>
            </div>
            <div className="col mb-3 mt-7">
              <div className="slide_item_img">
                <Image src={slide15} alt="image" />
              </div>
            </div>
            {/* <div className="col mb-3  ">
              <div className="slide_item_img">
                <Image src={slide16} alt="image" />
              </div>
            </div> */}
            </Marquee>
          </div>
        </div>
      </div>
    </>
  )
}

export default AtaGlance